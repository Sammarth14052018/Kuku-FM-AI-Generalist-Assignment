# lawyer_up_ai

`lawyer_up_ai` is a Streamlit workspace for researching Indian law. Ask a question and inspect the retrieved passages alongside the answer. Sources show the PDF filename and page number, with links to the official PDFs in the starter collection.

## Project flowchart

```mermaid
flowchart TD
    subgraph setup["Preparing the live index"]
        pdf["Official legal PDFs"] --> extract["Extract passages and keep page numbers"]
        extract --> index[("Passages and embeddings in Pinecone")]
    end

    question["Ask a question in Streamlit"] --> mode{"Which mode is running?"}
    mode -->|Demo| demo["Choose a sample to see its preset answer and sources"]
    mode -->|Live| retrieve["Embed the question and retrieve matching passages"]
    index --> retrieve
    retrieve --> evidence{"Any passages meet the relevance threshold?"}
    evidence -->|No| leads["Report insufficient evidence and show any optional SerpAPI leads"]
    evidence -->|Yes| draft["Groq drafts an answer from the retrieved passages"]
    draft --> citations{"Does the draft cite passages by valid source numbers?"}
    citations -->|Yes| answer["Show the answer beside the passages and PDF page numbers"]
    citations -->|No| review["Report insufficient evidence and show the passages for review"]
```

## Quick start

Use Python 3.11 or 3.12. Run these commands from the project directory on macOS or Linux:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirement.txt
streamlit run streamlit_app.py
```

Open [the local workspace](http://127.0.0.1:8501) and choose a sample question. The demo uses preset answers and runs without API keys.

## Live research

### Configure API keys

Copy the template to `.env` if you do not already have one:

```bash
cp -n .env.example .env
```

| Variable | Purpose |
| --- | --- |
| `GROQ_API_KEY` | Required. Generates answers from retrieved passages. |
| `PINECONE_API_KEY` | Required. Stores and retrieves passage embeddings. |
| `SERPAPI_API_KEY` | Optional. Finds links to official resources when indexed evidence is weak. |
| `GROQ_MODEL` | Selects the generation model. Defaults to `openai/gpt-oss-120b`. |
| `PINECONE_INDEX` | Names the vector index. Defaults to `law-suggestion-index`. |
| `PINECONE_NAMESPACE` | Names the corpus within the index. Defaults to `lexai-v1`. |

Fill in your API keys in `.env`. Git ignores this file.

### Download and index the corpus

Run the first code cell in [agent.ipynb](agent.ipynb) or use the Python command below. Both fetch the same eight official PDFs into `data/legal/`. The collection includes the Bharatiya Nyaya Sanhita, 2023, and Acts covering topics such as dowry, workplace harassment, and domestic violence. The source URLs are listed in [download_sources.py](download_sources.py).

```bash
python download_sources.py
python ingest.py data/legal --ocr
```

The `--ocr` flag lets the indexer read scanned pages and requires Tesseract with English language data. The first indexing run downloads the embedding model. The indexer creates the configured Pinecone index if needed, and uploaded passages may take a short time to become searchable.

To add more legislation, place public PDFs in `data/legal/` with descriptive filenames. Re-running ingestion with identical files updates the existing records. When replacing or removing PDFs, index the revised collection into a fresh `PINECONE_NAMESPACE` and restart the app with that namespace.

### Start Streamlit

Stop the demo first if it is using port 8501, then run:

```bash
streamlit run streamlit_app.py -- --live
```

Try asking **Under which section of the Bharatiya Nyaya Sanhita, 2023 is theft defined?** Open the linked PDF in the evidence panel to check the cited page.

## How it works

1. The indexer splits PDFs into passages, preserves their page numbers, and stores 384-dimensional embeddings in Pinecone.
2. The app embeds each question and retrieves relevant passages. If the question names an Act from the starter collection, it also searches within that Act.
3. Groq generates an answer using the retrieved passages and cites them by number. The app reports insufficient evidence if the retrieval is weak or the answer lacks valid source references. Optional SerpAPI results appear as research leads.
4. Streamlit displays the answer and evidence together. Passages extracted by OCR are labeled so you can compare the transcription with the original page.

Citation checks confirm that the answer points to a retrieved source. Verify that each cited passage supports the claim and that the law applies to the relevant place and date. This project provides general legal information. Consult a qualified lawyer for advice about your situation.

Live mode sends the question and selected excerpts to Groq and the query embedding to Pinecone. When enabled, SerpAPI receives the question on the search fallback. Leave out names, contact details, and other personal information.

## Project files

| File | Purpose |
| --- | --- |
| [streamlit_app.py](streamlit_app.py) | Question form, answer, and evidence panel |
| [research.py](research.py) | Evidence filtering, citation checks, and demo responses |
| [providers.py](providers.py) | Pinecone retrieval, Groq generation, and optional web search |
| [download_sources.py](download_sources.py) | Official source URLs and PDF downloads |
| [ingest.py](ingest.py) | PDF text extraction, OCR, and vector indexing |
| [agent.ipynb](agent.ipynb) | PDF download cell and original LangGraph retrieval experiment |

## Tests

```bash
python -m unittest discover -s tests
```

The tests cover the Streamlit demo, blank input validation, and how the research pipeline handles weak evidence and missing citations.

## Roadmap

1. Build a lawyer-reviewed evaluation set for citation accuracy, jurisdiction, and effective dates.
2. Add exact Act and section lookup and measure it against semantic retrieval.
3. Track the versions and dates of source documents before expanding coverage.


