# Slate Check · Kuku Problem 3

A commissioning editor can audit a batch of US vertical microdrama loglines before sending them to script. Start with [the solution brief](solution.pdf), [research and sources](RESEARCH.md), or the [unedited demo output](raw_outputs/sample-report.md).

## Run from ps3

Python 3.9+ with its standard library. The demo uses six original pitches and saved AI-authored annotations and alternatives. Scoring, validation, ranking and rendering run on each invocation.

```sh
python3 -B -m slate --demo
python3 -B -m slate --demo --output raw_outputs/sample-report.md
python3 -B -m unittest discover -s tests -v
```

For new pitches, set OPENAI_API_KEY in your shell. MODEL optionally overrides gpt-4.1-mini. Live mode sends only the selected inputs and instructions to OpenAI. Supply one complete pitch per nonblank line. For optional dialogue checks, pass repeatable `--script path/to/script.txt` arguments with one complete dialogue turn per physical line.

```sh
python3 -B -m slate --input examples/slate.txt --threshold 0.30 --output report.md
python3 -B -m slate --slate-size 20 --output generated.md
```

Omitting input or supplying a blank file generates 20 two-sentence pitches by default. Existing loglines keep their order and wording. Output is Markdown with seven sections and a final CSV block. The checked-in run uses the offline path. Live output depends on the model.

## How it works

| Module | Responsibility |
|---|---|
| slate/__main__.py | Entry point, input files, demo replay and output |
| slate/provider.py | JSON model requests |
| slate/schema.py | Category vocabulary, word limits and evidence validation |
| slate/pipeline.py | Generation, five-pitch extraction batches, targeted rewrites and optional dialogue check |
| slate/scoring.py | Known-value shares, joint score and five-pitch priority list |
| slate/report.py | Markdown distributions, review notes and CSV serialization |

Each field excludes unknowns from its own denominator. Every value strictly above the threshold is flagged. The joint score uses the full slate and the single most common twist and role. Alphabetical order breaks modal ties, which the report discloses. Candidates rank by flagged-field count, then input order. The UI for this prototype is the CLI and its shareable report.

The checker validates declared replacement labels, evidence and word limits. An editor must still verify semantic consistency and whether each intervention improves the pitch. Unknown cities can make a single named location look unusually common. Exposition inspection assumes dialogue has already been split into speaker turns.

## Assignment materials

The original test slate and replay data are in examples/. The unedited run is in raw_outputs/. The private screenplay pack is unnecessary for Problem 3. To share, distribute this ps3 directory. Hosting, student details and form submission are outside this local deliverable.
